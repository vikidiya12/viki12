<footer>
        <p>Copyright © 2018 Student Portal</p>
    </footer>