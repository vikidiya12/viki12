<?php include"assest/common/doctype.php" ?>
<?php include"assest/common/all-links.php" ?>
</head>

<body>

    <section class="ic-firtst">
        <div class="container">
            <div class="ic-fulldiv">
                <h1 class="ic-h1 text-center">Student Profile</h1>
                <h3 class="ic-h3 text-center">P.G & researchh department of history</h3>
                <p class="ic-para text-center">islamiah college (autonomous), vaniyambadi</p>
                <div class="col-lg-9 ic-forms">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Name</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder="Name">
                        </div>                        
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Name</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder="Name">
                        </div>                        
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Name</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder="Name">
                        </div>                        
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Name</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder="Name">
                        </div>                        
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Name</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder="Name">
                        </div>                        
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Name</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder="Name">
                        </div>                        
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Name</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder="Name">
                        </div>                        
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Name</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder="Name">
                        </div>                        
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Name</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder="Name">
                        </div>                        
                    </div>
                </div>
                <div class="col-lg-3 ic-forms pull-right">
                    <div class="ic-img">
                        <input type="file" class="ic-photo">
                        <p class="ic-img-para">Afix Photo</p>
                    </div>
                </div>
            </div>
        </div>
    </section>








    <script src="assest/js/common.js"></script>
</body>

</html>
